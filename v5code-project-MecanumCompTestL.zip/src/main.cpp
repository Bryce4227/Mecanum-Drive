/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// leftF                motor         1               
// leftB                motor         2               
// rightF               motor         3               
// rightB               motor         4               
// Controller1          controller                    
// Vision               vision        5               
// Intake               motor         6               
// CatapultGroup        motor_group   7, 8   
//Rollers/Intake are front of the robot         
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;
using namespace std;

// A global instance of competition
competition Competition;

//How far the motors need to turn to turn the robot 90 degrees
#define MY90DEGREE 720

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

//Functions for autonomous
void moveForward(int degrees, int speed) {
  leftF.rotateFor(degrees, deg, speed, rpm, false);
  leftB.rotateFor(degrees, deg, speed, rpm, false);
  rightF.rotateFor(degrees, deg, speed, rpm, false);
  rightB.rotateFor(degrees, deg, speed, rpm, true);
}

void moveBackward(int degrees, int speed) {
  leftF.rotateFor(-degrees, deg, speed, rpm, false);
  leftB.rotateFor(-degrees, deg, speed, rpm, false);
  rightF.rotateFor(-degrees, deg, speed, rpm, false);
  rightB.rotateFor(-degrees, deg, speed, rpm, true);
}

void moveRight(int degrees, int speed) {
  leftF.rotateFor(degrees, deg, speed, rpm, false);
  rightB.rotateFor(degrees, deg, speed, rpm, false);
  leftB.rotateFor(-degrees, deg, speed, rpm, false);
  rightF.rotateFor(-degrees, deg, speed, rpm, true);
}

void moveLeft(int degrees, int speed) {
  leftF.rotateFor(-degrees, deg, speed, rpm, false);
  rightB.rotateFor(-degrees, deg, speed, rpm, false);
  leftB.rotateFor(degrees, deg, speed, rpm, false);
  rightF.rotateFor(degrees, deg, speed, rpm, true);
}

void diagonalForwardRight(int degrees, int speed) {
  leftF.rotateFor(degrees, deg, speed, rpm, false);
  rightB.rotateFor(degrees, deg, speed, rpm, true);
}

void diagonalForwardLeft(int degrees, int speed) {
  leftB.rotateFor(degrees, deg, speed, rpm, false);
  rightF.rotateFor(degrees, deg, speed, rpm, true);
}

void diagonalBackwardRight(int degrees, int speed) {
  leftF.rotateFor(-degrees, deg, speed, rpm, false);
  rightB.rotateFor(-degrees, deg, speed, rpm, true);
}

void diagonalBackwardLeft(int degrees, int speed) {
  leftB.rotateFor(-degrees, deg, speed, rpm, false);
  rightF.rotateFor(-degrees, deg, speed, rpm, true);
}

void turnOnRearAxisRight(int degrees, int speed) {
  leftF.rotateFor(degrees, deg, speed, rpm, false);
  rightF.rotateFor(-degrees, deg, speed, rpm, true);
}
void turnOnRearAxisLeft(int degrees, int speed) {
  leftF.rotateFor(-degrees, deg, speed, rpm, false);
  rightF.rotateFor(degrees, deg, speed, rpm, true);
}

void turnAroundClockwise(int degrees, int speed) {
  leftF.rotateFor(degrees, deg, speed, rpm, false);
  leftB.rotateFor(degrees, deg, speed, rpm, false);
  rightF.rotateFor(-degrees, deg, speed, rpm, false);
  rightB.rotateFor(-degrees, deg, speed, rpm, true);
}

void turnAroundCounterClockwise(int degrees, int speed) {
  leftF.rotateFor(-degrees, deg, speed, rpm, false);
  leftB.rotateFor(-degrees, deg, speed, rpm, false);
  rightF.rotateFor(degrees, deg, speed, rpm, false);
  rightB.rotateFor(degrees, deg, speed, rpm, true);
}

void stopMotors() {
  leftB.stop();
  leftF.stop();
  rightF.stop();
  rightB.stop();
}

//Stage plan 
bool preAutonDone;
bool posOne = true;
bool maroon = true;
void redAlliance() {
  if (preAutonDone) {
    return;
  }
  maroon = true;
}

void blueAlliance() {
  if (preAutonDone) {
    return;
  }
  maroon = false;
}

void positionOne() {
  if (preAutonDone) {
    return;
  }
  posOne = true;
}

void positionTwo() {
  if (preAutonDone) {
    return;
  }
  posOne = false;
}

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit(); 
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("A=red B=blue");
  Controller1.Screen.print("X=1 Y=2");
  Controller1.ButtonA.pressed(redAlliance);
  Controller1.ButtonB.pressed(blueAlliance);
  Controller1.ButtonX.pressed(positionOne);
  Controller1.ButtonY.pressed(positionTwo);
  


 
  while (1) {
    Controller1.Screen.setCursor(2,1);
    if (maroon) {
      Controller1.Screen.print("Red  ");
    } else {
      Controller1.Screen.print("Blue ");
    }
    if (posOne) {
      Controller1.Screen.print("position 1");
    } else {
      Controller1.Screen.print("position 2");
    }
    if (Controller1.ButtonRight.pressing()){
      preAutonDone = true;
      break;
    }
    wait(100, msec);
  }
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/


void autonomous(void) {
  maroon = true;
  posOne = true;
  //Position one is touching the roller
  //Spin the roller
  //Move backwards slightly
  //Turn right 90 degrees
  //Drive backward into low goal
  //Delivery preloaded discs into low goal
  if (posOne){
    Controller1.Screen.setCursor(3,1);
    Controller1.Screen.print("Red 1");
    Intake.spinFor(forward, 45, degrees);
    moveBackward(180, 100);
    moveLeft(2000, 100);
    turnAroundClockwise(MY90DEGREE, 100);
    CatapultGroup.spinFor(forward, 720, degrees);
  }
  //Move backward slightly to stop touching wall
  //Move left until in front of roller
  //Move into backward roller and spin
  //Move slightly backward to stop touching roller
  //Move left into red low goal
  //Rotate CounterClockwise 
  if (!posOne){
    moveBackward(180, 100);
    moveLeft(720, 100);
    moveForward(250, 100);
    Intake.spinFor(forward, 45, degrees);
    moveBackward(180, 100);
    moveRight(2000, 100);
    turnAroundCounterClockwise(MY90DEGREE, 100);
    CatapultGroup.spinFor(forward, 720, degrees);
  }
  /*if (!maroon && posOne){
    Controller1.Screen.print("blue one");
    diagonalForwardLeft(60, 100);
  }
  if (!maroon && !posOne){
    diagonalForwardLeft(60, 100);
    moveLeft(100, 100);
    moveRight(500, 100);
  }*/
  stopMotors();
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  while (1) {

  //Arcade drive for Mecanum
  int forward1 = Controller1.Axis3.position(vex::percent);
  int sideways = Controller1.Axis4.position(vex::percent);
  int turn = Controller1.Axis1.position(vex::percent);

  rightF.spin(vex::forward, forward1 - sideways - turn, vex::percent);
  leftF.spin(vex::forward,  forward1 + sideways + turn, vex::percent);
  rightB.spin(vex::forward,  forward1 + sideways - turn, vex::percent);
  leftB.spin(vex::forward,   forward1 - sideways + turn, vex::percent);

    //If the Vision sensor sees the disc it activates the Intake by itself
    if (Vision.objects[1].exists){
      Intake.spin(forward);
    } else {
      Intake.stop(); 
    }

    wait(20, msec); 
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();
  
  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
