/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// leftF                motor         1               
// leftB                motor         2               
// rightF               motor         3               
// rightB               motor         4               
// Controller1          controller                    
// Vision               vision        5               
// Intake               motor         6               
// CatapultGroup        motor_group   7, 8            
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;
using namespace std;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

//Functions for autonomous
void moveForward(int degrees, int speed) {
  leftF.rotateFor(degrees, deg, speed, rpm);
  leftB.rotateFor(degrees, deg, speed, rpm);
  rightF.rotateFor(degrees, deg, speed, rpm);
  rightB.rotateFor(degrees, deg, speed, rpm);
}

void moveBackward(int degrees, int speed) {
  leftF.rotateFor(-degrees, deg, speed, rpm);
  leftB.rotateFor(-degrees, deg, speed, rpm);
  rightF.rotateFor(-degrees, deg, speed, rpm);
  rightB.rotateFor(-degrees, deg, speed, rpm);
}

void moveRight(int degrees, int speed) {
  leftF.rotateFor(degrees, deg, speed, rpm);
  rightB.rotateFor(degrees, deg, speed, rpm);
  leftB.rotateFor(-degrees, deg, speed, rpm);
  rightF.rotateFor(-degrees, deg, speed, rpm);
}

void moveLeft(int degrees, int speed) {
  leftF.rotateFor(-degrees, deg, speed, rpm);
  rightB.rotateFor(-degrees, deg, speed, rpm);
  leftB.rotateFor(degrees, deg, speed, rpm);
  rightF.rotateFor(degrees, deg, speed, rpm);
}

void diagonalForwardRight(int degrees, int speed) {
  leftF.rotateFor(degrees, deg, speed, rpm);
  rightB.rotateFor(degrees, deg, speed, rpm);
}

void diagonalForwardLeft(int degrees, int speed) {
  leftB.rotateFor(degrees, deg, speed, rpm);
  rightF.rotateFor(degrees, deg, speed, rpm);
}

void diagonalBackwardRight(int degrees, int speed) {
  leftF.rotateFor(-degrees, deg, speed, rpm);
  rightB.rotateFor(-degrees, deg, speed, rpm);
}

void diagonalBackwardLeft(int degrees, int speed) {
  leftB.rotateFor(-degrees, deg, speed, rpm);
  rightF.rotateFor(-degrees, deg, speed, rpm);
}

void turnOnRearAxisRight(int degrees, int speed) {
  leftF.rotateFor(degrees, deg, speed, rpm);
  rightF.rotateFor(-degrees, deg, speed, rpm);
}
void turnOnRearAxisLeft(int degrees, int speed) {
  leftF.rotateFor(-degrees, deg, speed, rpm);
  rightF.rotateFor(degrees, deg, speed, rpm);
}

void turnAroundClockwise(int degrees, int speed) {
  leftF.rotateFor(degrees, deg, speed, rpm);
  leftB.rotateFor(degrees, deg, speed, rpm);
  rightF.rotateFor(-degrees, deg, speed, rpm);
  rightB.rotateFor(-degrees, deg, speed, rpm);
}

void turnAroundCounterClockwise(int degrees, int speed) {
  leftF.rotateFor(-degrees, deg, speed, rpm);
  leftB.rotateFor(-degrees, deg, speed, rpm);
  rightF.rotateFor(degrees, deg, speed, rpm);
  rightB.rotateFor(degrees, deg, speed, rpm);
}


//Stage plan 
int stage = 0;
bool posOne;
bool posTwo;
bool maroon;
bool turquoise;
void redAlliance() {
  maroon = true;
  ++stage;
}

void blueAlliance() {
  turquoise = true;
  stage = stage + 1;
}

void positionOne() {
  posOne = true;
  ++stage;
}

void positionTwo() {
  posTwo = true;
  ++stage;
}

/*if (1) {
    Controller1.Screen.print("Press A for maroon alliance or B for turquoise alliance.");
    Controller1.ButtonA.pressed(redAlliance);
    Controller1.ButtonB.pressed(blueAlliance);
    
    if (red == true) {
      Controller1.Screen.clearLine();
      Controller1.Screen.print("You are set for maroon alliance");
    }

    if (blue == true) {
      Controller1.Screen.clearLine();
      Controller1.Screen.print("You are set for turquoise alliance");
    }
      
      if (stage == 1) {


        
        Controller1.Screen.newLine();
        Controller1.Screen.print("Press X for position 1 or Y for position 2.");
        Controller1.ButtonX.pressed(positionOne);
        Controller1.ButtonY.pressed(positionTwo);
        if (posOne == true) {
        Controller1.Screen.clearLine();
        Controller1.Screen.print("You are set for position 1");
        }      
        if (posTwo == true) {
        Controller1.Screen.clearLine();
        Controller1.Screen.print("You are set for position 2");
        }
    }
  }
*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit(); 
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("A=redB=blue");
  Controller1.Screen.print("X=1Y=2");
  
 
  while (1) {
    Controller1.Screen.setCursor(2,1);
    Controller1.Screen.print(stage);
    Controller1.Screen.setCursor(3,1);  
    Controller1.Screen.clearLine(3);
    Controller1.Screen.print("Red:");
    Controller1.Screen.print(maroon);
    Controller1.Screen.print("Blue:");
    Controller1.Screen.print(turquoise);
    Controller1.Screen.print("One:");
    Controller1.Screen.print(posOne);
    Controller1.Screen.print("Two:");
    Controller1.Screen.print(posTwo);
    Controller1.ButtonA.pressed(redAlliance);
    Controller1.ButtonB.pressed(blueAlliance);
    Controller1.ButtonX.pressed(positionOne);
    Controller1.ButtonY.pressed(positionTwo);

    if (maroon = true && posOne = true){
    turquoise = false;
    posTwo = false;
  }
    if (maroon = true, posTwo){
    turquoise = false;
    posOne = false;
  }
    if (turquoise = true, posOne){
    maroon = false;
    posTwo = false;
  }
    if (turquoise = true, posTwo){
    maroon = false;
    posOne = false;
  }

    wait(2, sec);
  }
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/


void autonomous(void) {
  if (maroon = true, posOne = true){
    Controller1.Screen.clearScreen();
  }
  if (maroon = true, posTwo){
    moveForward(360, 100);
    turnAroundClockwise(360, 100);
    maroon = false;
    posTwo = false;
  }
  if (turquoise = true, posOne){
    moveForward(360, 100);
    turnAroundClockwise(360, 100);
    turquoise = false;
    posOne = false;
  }
  if (turquoise = true, posTwo){
    moveForward(360, 100);
    turnAroundClockwise(360, 100);
    turquoise = false;
    posTwo = false;
  }
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  while (1) {

  //Arcade drive for Mecanum
  int forward1 = Controller1.Axis3.position(vex::percent);
  int sideways = Controller1.Axis4.position(vex::percent);
  int turn = Controller1.Axis1.position(vex::percent);

  rightF.spin(vex::forward, forward1 - sideways - turn, vex::percent);
  leftF.spin(vex::forward,  forward1 + sideways + turn, vex::percent);
  rightB.spin(vex::forward,  forward1 + sideways - turn, vex::percent);
  leftB.spin(vex::forward,   forward1 - sideways + turn, vex::percent);

    //If the Vision sensor sees the disc it activates the Intake by itself
    if (Vision.objects[1].exists){
      Intake.spin(forward);
    } else {
      Intake.stop(); 
    }

    wait(20, msec); 
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();
  
  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
